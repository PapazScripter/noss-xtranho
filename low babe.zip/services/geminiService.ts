// This file is deprecated. All game logic has been moved to utils/gameLogic.ts.
// AI dependency has been removed.
export {};